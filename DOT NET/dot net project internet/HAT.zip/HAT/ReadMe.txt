Steps to do to run the application
============================
1. Open Visual Studio 2005.
2. File > Open Website 
3. Select the location
4. Change the database file (.mdb) location in the web.confile file (value of "ConnString" connection string)
4. Run the application.
5. Username/passwrod = demo/demo